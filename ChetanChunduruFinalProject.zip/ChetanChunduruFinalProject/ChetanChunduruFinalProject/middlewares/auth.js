const Item = require('../models/item')
const tradingModel = require("../models/trading")
exports.isGuest = (req, res, next)=>{
    if(!req.session.user){
        return next()
    }else {
         req.flash('error', 'You are logged in already')
         return res.redirect('/users/profile')
     }
}

exports.isLoggedIn = (req, res, next) =>{
    if(req.session.user){
        return next()
    }else {
         req.flash('error', 'You need to log in first')
         return res.redirect('/users/login')
     } }

exports.isAuthor = (req, res, next) =>{
    let id = req.params.id
    Item.findById(id)
    .then(item=>{
        if(item) {
            if(item.author == req.session.user) {
                return next()
            } else {
                let err = new Error('Unauthorized to access the resource')
                err.status = 401
                return next(err)
            }
        } else {
            let err = new Error('Cannot find a connection with id ' + req.params.id)
            err.status = 404
            return next(err)
        }
    })
    .catch(err=>next(err))
}

exports.istradeOfferedBy = (req, res, next) => {
    id = req.params.id
    Item
      .findById(id)
      .then((item) => {
        let name = item.title
        tradingModel
          .findOne({ title: name })
          .then((item) => {
            if (item) {
              if (item.tradeOfferedBy == req.session.user) {
                return next()
              } else {
                let err = new Error("you are not authorised to perform action")
                err.status = 401
                next(err)
              }
            } else {
              let error = new Error("No Item found with id  " + id)
              error.status = 404
              next(error)
            }
          })
          .catch((err) => {
            next(err)
          })
      })
      .catch((err) => {
        next(err)
      })
}
  