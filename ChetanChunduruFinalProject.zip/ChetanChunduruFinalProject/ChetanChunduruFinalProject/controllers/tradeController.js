const { json } = require("express")
const model = require("../models/item")
const watchModel = require("../models/watch")
const tradingModel = require("../models/trading")

exports.index = (req, res, next) => {
  model
    .find()
    .then((trades) => res.render("./trade/index", { trades }))
    .catch((err) => next(err))
}

exports.new = (req, res) => {
  res.render("./trade/new")}

exports.create = (req, res, next) => {
  let trade = new model(req.body)
  trade.author = req.session.user
  trade.offerName = ""
  trade.Saved = false
  trade.tradeOffered = false
  trade.Status = "Available"
  trade.save()
    .then((trade) => {
      req.flash("success", "Story has been created successfully")
      res.redirect("/trades")
    })
    .catch((err) => {
      if (err.name === "ValidationError") {
        req.flash("error", err.message)
        return res.redirect("back")
      }
      next(err)
    })}

exports.watch = (req, res, next) => {
  let userId = req.session.user
  let tradeId = req.params.id
  model.findOne({title:userId,author:tradeId})
  .then(trade => {
    console.log(trade)
    if(!trade){
      const watchModelList = new watchModel({userID:userId,tradeId:tradeId})
      watchModelList.save()
      .then((tradeItem) => {
        console.log(tradeItem)
        req.flash('success', 'This trade is added to watchList')
        res.redirect('/trades/'+tradeId);
      })
      .catch(err => {
        req.flash('error', 'Failed to add trade to watchlist')
        next(err)
    })
    }
    else{
      req.flash('success', 'This trade is already watchlisted.')
      res.redirect('/trades/'+tradeId);
    }
  })
  .catch(err => {
    req.flash('error', 'Failed to add trade to watchlist')
    next(err)
})
}

exports.show = (req, res, next) => {
  let id = req.params.id
  let user = req.session.user
  model.findById(id).populate("author", "firstName lastName")
  .then((trade) => {
    if (trade) {
      watchModel.findOne({ userID : user, tradeId : id })
      .then((tradeItem) => {
        console.log(tradeItem)
        let watched = false
        if(tradeItem){
          watched = true
        }
        else{
          watched = false
        }
      return res.render("./trade/show", { trade,watched })
      })
      .catch(err => {
        req.flash('error', 'Failed to add trade to watchlist')
        next(err);
    })
    } else {
      let err = new Error("Cannot find a trade with id " + id)
      err.status = 404
      next(err)
    }
  })
  .catch(err => {
    if (err.name === 'ValidationError') {
        err.status = 400;
        req.flash('error', err.message)
        res.redirect('back') 
    }
    next(err);
});
}
exports.edit = (req, res, next) => {
  let id = req.params.id
  model
    .findById(id)
    .then((trade) => {
      return res.render("./trade/edit", { trade })
    })
    .catch((err) => next(err))}

exports.update = (req, res, next) => {
  let trade = req.body
  let id = req.params.id
  model
    .findByIdAndUpdate(id, trade, {
      useFindAndModify: false,
      runValidators: true,
    })
    .then((trade) => {
      return res.redirect("/trades/" + id)
    })
    .catch((err) => {
      if (err.name === "ValidationError") {
        req.flash("error", err.message)
        return res.redirect("/back")
      }
      next(err)
    })}

exports.delete = (req, res, next) => {
  let id = req.params.id
  model
    .findByIdAndDelete(id, { useFindAndModify: false })
    .then((trade) => {
      if (trade) {
        watchModel
          .deleteMany({ tradeId: req.params.id })
          .then((tradeList) => {
            req.flash("success", "Trade deleted successfully")
            res.redirect("/trades")
          })
          .catch((err) => next(err))
      } else {
        let err = new Error("Cannot find a trade with id " + req.params.id)
        err.status = 404
        next(err)
      }
    })
    .catch((err) => next(err))
}
exports.trade = (req, res, next) => {
  let user = req.session.user
  iD = req.params.id
  model.findByIdAndUpdate(iD,{ Status: "Offer Pending", tradeOffered: true },{  useFindAndModify: false,  runValidators: true})
  .then((trade) => {
    let newOfferItem = new tradingModel({
      Name: trade.title,
      Status: "Offer Pending",
      Category: trade.category,
      tradeOfferedBy: user,
    })
    newOfferItem.save().then((offer) => {
      model.find({ author: user })
        .then((trades) => {
          res.render("./trade/startTrade", { trades })
        })
        .catch((err) => {
          next(err)
        })
    })
    })
    .catch((err) => {
      next(err)
    })
    .catch((err) => {
      next(err)
    })}

exports.itemTrading = (req, res, next) => {
  let id = req.params.id
  let user = req.session.user
  Promise.all([model.findByIdAndUpdate(id,{ Status: "Offer Pending" },{useFindAndModify: false,runValidators: true}),tradingModel.findOne({ tradeOfferedBy: user})])
    .then((results) => {
      const [trade, tradeOffered] = results
      let name = tradeOffered.Name
      model.findByIdAndUpdate(id,{ offerName: name },{useFindAndModify: false,runValidators: true})
        .then((trade) => {
          req.flash("success", "Offer Created")
          res.redirect("/users/profile")
        })
        .catch((err) => {
          next(err)
        })
    })
    .catch((err) => {
      next(err)
    })}
exports.manage = (req, res, next) => {
  let id = req.params.id
  let user = req.session.user
  model.findById(id)
  .then((item) => {
    if (item.offerName === "") {
      let name = item.title
      model.find({ offerName: name })
        .then((offer) => {
          res.render("./trade/manage", {offer})
        })
        .catch((err) => {
          next(err)
        })
    } else {
      let name = item.offerName
      tradingModel.findOne({ Name: name })
        .then((offer) => {
          res.render("./trade/offerManage", { item, offer })
        })
        .catch((err) => {next(err)})
    }
  })
  .catch((err) => {
    next(err)
  })
}

exports.accept = (req, res, next) => {
  let id = req.params.id
  model.findByIdAndUpdate(id,{ Status: "Traded" },{useFindAndModify: false, runValidators: true})
  .then((trade) => {
    let name = trade.offerName
    Promise.all([model.findOneAndUpdate({ title: name},{ Status: "Traded"},{useFindAndModify: false,runValidators: true}),
      tradingModel.findOneAndDelete({ Name: name },{ useFindAndModify: false })])
      .then((results) => {
        const [trade, offer] = results
        req.flash("success", "You have accepted this trade!!")
        res.redirect("/users/profile")
      })
      .catch((err) => {
        next(err)
      })
  })
  .catch((err) => {next(err)})
}

exports.reject = (req, res, next) => {
  let id = req.params.id
  model.findByIdAndUpdate(id,{ Status: "Available", offerName: "" },{useFindAndModify: false,runValidators: true})
    .then((trade) => {
      let name = trade.offerName
      Promise.all([
        model.findOneAndUpdate({ title: name },{ Status: "Available", tradeOffered: false },{useFindAndModify: false,runValidators: true}),tradingModel.findOneAndDelete({ Name: name })])
        .then((results) => {
          const [trade, offer] = results
          let name = trade.Name
          let status = trade.Status
          if (trade.Saved) {
            save_model.findOneAndUpdate({ Name: name },{ Status: status },{useFindAndModify: false,runValidators: true})
              .then((save) => {})
              .catch((err) => {
                next(err)
              })
          }
          req.flash("success", "You have rejected this trade")
          res.redirect("/users/profile")
        })
        .catch((err) => {
          next(err)
        })
    })
    .catch((err) => {
      next(err)
    })
}

exports.cancelOffer = (req, res, next) => {
  let id = req.params.id
  model.findByIdAndUpdate(id,{ Status: "Available", tradeOffered: false },{useFindAndModify: false,runValidators: true})
    .then((trade) => {
      let name = trade.title
      console.log(trade)
      Promise.all([model.findOneAndUpdate({ offerName: name },{ Status: "Available", offerName: "" }),
        tradingModel.findOneAndDelete({ Name: name },{ useFindAndModify: false })])
        .then((results) => {
          req.flash("success", "You have cancelled this offer!")
          res.redirect("/users/profile")
        })
        .catch((err) => {
          next(err)
        })
    })
    .catch((err) => {
      next(err)
    })
}

exports.managecancelOffer = (req, res, next) => {
  let id = req.params.id
  model.findByIdAndUpdate(id, { Status: "Available", offerName: "" })
    .then((trade) => {
      let name = trade.offerName
      Promise.all([tradingModel.findOneAndDelete({ Name: name }),model.findOneAndUpdate({ Name: name },{ Status: "Available", tradeOffered: false })])
        .then((results) => {
          req.flash("success", "Offer cancelled by You!!")
          res.redirect("/users/profile")
        })
        .catch((err) => {
          next(err)
        })
    })
    .catch((err) => {
      next(err)
    })
}

exports.deletefav = (req, res, next) => {
  let id = req.params.id
  model
    .findByIdAndUpdate(id, { Saved: false })
    .then((trade) => {
        watchModel.findOneAndDelete({ userID: req.session.user },{ useFindAndModify: false })
        .then((save) => {
            req.flash("success", "trade unwatched")
            res.redirect("back")
        })
        .catch((err) => {
            next(err)
        })
    })
    .catch((err) => {
        next(err)
    })
}